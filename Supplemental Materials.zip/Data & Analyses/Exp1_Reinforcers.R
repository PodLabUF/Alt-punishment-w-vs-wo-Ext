#title: GLMER Punishment Magnitude
#Based on code by Carla N Martinez and Carolyn M Ritchey
#date: October, 2025
rm(list = ls())
library(boot) #for bootstrapping
library(DHARMa) # Both have model diagnostic tools for LME
library(emmeans) # Helps interpreting LME models
library(ggplot2) # Charting
library(ggpubr) #for publication-ready plots
library(knitr) #for compiling the code into text or graphics
library(lmerTest) # Satterthwaite's approximation (p values for LME)
library(MuMIn) #for model inference (AIC and BIC)
library(nlme) #for non-linear MEM
library(tidyverse) # Data management
library(vcdExtra) #for visualizing categorical data (helpful for glmer)
library(aods3) #for analysis of overdispersion
library(stringr) #for manipulating characters
library(glmmTMB)
library("readxl")
library(writexl)
library("vcdExtra")
library(dplyr)
library(effsize)

#######
#Introduction 
#**ID**            = participant ID N = 247
#**Phase**         = Reinforcement contingency in standard protocol. There are 3 phases and an additional extinction test
#*#**Group**         = -1, -100, -320, -1000
#**Rate**          = response rate (count variable). Number of responses that occur in a 60-second interval. 
#**Bin**   = nth minute of exposure to overall protocol, numbered in ordinarily (i.e., 1-15)
#######
#Modify Working Directory
setwd("/Users/angelvillalobos/Desktop/LAB/Projects/Punishment/Alt Punish Magnitude/Submission/GitHub/")
directory <-getwd()
All_Data <- read_xlsx(file.path(directory, "Exp 1 Additive_Data.xlsx"))

resp_model <- "Reinforcer"

Data_Target <- All_Data %>%
  filter(RespType == resp_model, Phase %in% c("B-1", "A-2", "C-3"))
Data_Target$ID <- as.factor(Data_Target$ID)
Data_Target$Group <- as.factor(Data_Target$Group)
Data_Target$Phase <- as.factor(Data_Target$Phase)
##Data Inspection
Data_Target %>% 
  ggplot(aes(x = Bin, 
             y = Rate,
             color = Group))+
  geom_line(aes(group = ID),
            linewidth   = 0.3)+
  geom_vline(xintercept = c(5.5, 10.5, 15.5))+
  theme_bw()

Data_Target %>%
  group_by(Group, Phase, Bin) %>%
  dplyr::summarize(rawMeans = mean(Rate),
                   se   = sd(Rate)/sqrt(n())) %>%
  ggplot(aes(x = Bin, y = rawMeans, color=Group)) +
  geom_line() +
  geom_errorbar(aes(ymin = rawMeans - se, ymax = rawMeans + se))+
  geom_vline(xintercept = c(5.5, 10.5, 15.5))+
  theme_bw()

#Null Model
Data_Empty <- glmmTMB(Rate ~ 1 + (1 | ID), 
                      family  = poisson,
                      data = Data_Target)
summary(Data_Empty)
performance::icc(Data_Empty)

zero.test(Data_Target$Rate)
prop_zeros <- mean(Data_Target$Rate == 0)
prop_zeros
var(Data_Target$Rate) / mean(Data_Target$Rate)

#Centering Bin
Data_Target$Bin_Centered <- Data_Target$Bin - mean(Data_Target$Bin, na.rm = TRUE)
#Adding observational-level
Data_Target$obs <- 1:nrow(Data_Target) 

model0 <- glmmTMB(Rate ~Bin_Centered*Phase*Group + (1|ID),
                  family = poisson,
                  Data_Target)
model1 <- glmmTMB(Rate ~Bin_Centered*Phase*Group + (1|ID),
                  family = nbinom2(),
                  Data_Target)
model2 <- glmmTMB(Rate ~Bin_Centered*Phase*Group + (1|ID),
                  ziformula = ~1,
                  family = nbinom2(),
                  Data_Target)
model3 <- glmmTMB(Rate ~Bin_Centered*Phase*Group + (1|ID),
                  ziformula = ~Phase,
                  family = nbinom2(),
                  Data_Target)

MuMIn::AICc(model0, model1, model2, model3)
anova(model0, model1, model2, model3)

bestModel <- model3

performance::icc(bestModel)
res <- simulateResiduals(bestModel, refit = F, n = 1000)
testZeroInflation(res)
summary(bestModel)$coefficients$zi
###Test to see if model accounts for overdispersion
testDispersion(res)

#Goodness of Fit
gof(bestModel) #X2/D
#Overdispertion Checks
overdisp_fun <- function(model) {
  rdf <- df.residual(model)
  rp <- residuals(model, type = "pearson")
  Pearson.chisq <- sum(rp^2)
  prat <- Pearson.chisq / rdf
  pval <- pchisq(Pearson.chisq, df = rdf, lower.tail = FALSE)
  c(chisq = Pearson.chisq, ratio = prat, rdf = rdf, p = pval)
}
#if the p-value is significant, there is overdispersion. 
overdispersionCheck <- overdisp_fun(bestModel)
print(overdispersionCheck)

car::Anova(bestModel)

summary(bestModel)

Data_Target$predg <- predict(bestModel, type = "response", re.form = NA)
Data_Target$predi <- predict(bestModel, type = "response")

#Post Hocs
#----Within Group comparison of Last of P1 vs. Last of P2-------
ioa1c <- emmeans(bestModel, pairwise ~ Bin_Centered * Phase * Group,
                 type = 'response',
                 CIs = TRUE,
                 plotit = FALSE,
                 adjust = "none",
                 at = list(
                   Bin_Centered = c(-3, 2)))
summary(ioa1c)

filtered_WGc <- ioa1c$contrasts %>%
  as.data.frame() %>%
  filter(
       contrast == "(Bin_Centered2 A-2 Group1) / (Bin_Centered-3 B-1 Group1)" |
      contrast == "(Bin_Centered2 A-2 Group2) / (Bin_Centered-3 B-1 Group2)" |
      contrast == "(Bin_Centered2 A-2 Group3) / (Bin_Centered-3 B-1 Group3)" |
      contrast == "(Bin_Centered2 A-2 Group4) / (Bin_Centered-3 B-1 Group4)" 
  )

kable(filtered_WGc) 
pfiltered_WGc <- filtered_WGc %>%
  mutate(p.adj = p.adjust(p.value, method = "holm"), 
         signif = cut(p.adj,
                      breaks = c(-Inf, 0.001, 0.01, 0.05, 0.1, Inf),
                      labels = c("***", "**", "*", ".", "")))
knitr::kable(pfiltered_WGc)

#----Between Group comparison of Last of P1-------
ioa1.p1c <- emmeans(bestModel, pairwise ~ Phase * Group,
                    type = 'response',
                    CIs = TRUE,
                    plotit = FALSE,
                    adjust = "none",
                    at = list(
                      Bin_Centered= c(-3)))
summary(ioa1.p1c)

filtered_BG1c <- ioa1.p1c$contrasts %>%
  as.data.frame() %>%
  filter(
    contrast == "(B-1 Group1) / (B-1 Group2)" |
      contrast == "(B-1 Group1) / (B-1 Group3)" |
      contrast == "(B-1 Group1) / (B-1 Group4)" |
      contrast == "(B-1 Group2) / (B-1 Group3)" |
      contrast == "(B-1 Group2) / (B-1 Group4)" |
      contrast == "(B-1 Group3) / (B-1 Group4)" 
    
  )
kable(filtered_BG1c)

pfiltered_BG1c <- filtered_BG1c %>%
  mutate(p.adj = p.adjust(p.value, method = "holm"), 
         signif = cut(p.adj,
                      breaks = c(-Inf, 0.001, 0.01, 0.05, 0.1, Inf),
                      labels = c("***", "**", "*", ".", "")))
knitr::kable(pfiltered_BG1c)

#----Between Group comparison of Last of P2-------
ioa1.p2c <- emmeans(bestModel, pairwise ~ Phase * Group,
                    type = 'response',
                    CIs = TRUE,
                    plotit = FALSE,
                    adjust = "none",
                    at = list(
                      Bin_Centered = c(2)))
summary(ioa1.p2c)

filtered_BG2c <- ioa1.p2c$contrasts %>%
  as.data.frame() %>%
  filter(
    contrast == "(A-2 Group1) / (A-2 Group2)" |
      contrast == "(A-2 Group1) / (A-2 Group3)" |
      contrast == "(A-2 Group1) / (A-2 Group4)" |
      contrast == "(A-2 Group2) / (A-2 Group3)" |
      contrast == "(A-2 Group2) / (A-2 Group4)" |
      contrast == "(A-2 Group3) / (A-2 Group4)" 
  )
kable(filtered_BG2c)
pfiltered_BG2c <- filtered_BG2c %>%
  mutate(p.adj = p.adjust(p.value, method = "holm"), 
         signif = cut(p.adj,
                      breaks = c(-Inf, 0.001, 0.01, 0.05, 0.1, Inf),
                      labels = c("***", "**", "*", ".", "")))
knitr::kable(pfiltered_BG2c)

#----Within Group comparison of Last of P2 vs. First of P3-------
ioa2c <- emmeans(bestModel, pairwise ~ Bin_Centered * Phase * Group,
                 type = 'response', 
                 CIs = TRUE,
                 plotit = FALSE,
                 adjust = "none",
                 at = list(
                   Bin_Centered = c(2, 3)))
summary(ioa2c)
filtered_WG2c <- ioa2c$contrasts %>%
  as.data.frame() %>%
  filter(
    contrast == "(Bin_Centered2 A-2 Group1) / (Bin_Centered3 C-3 Group1)" |
      contrast == "(Bin_Centered2 A-2 Group2) / (Bin_Centered3 C-3 Group2)" |
      contrast == "(Bin_Centered2 A-2 Group3) / (Bin_Centered3 C-3 Group3)" |
      contrast == "(Bin_Centered2 A-2 Group4) / (Bin_Centered3 C-3 Group4)" 
  ) 
kable(filtered_WG2c)
pfiltered_WG2c <- filtered_WG2c %>%
  mutate(p.adj = p.adjust(p.value, method = "holm"), 
         signif = cut(p.adj,
                      breaks = c(-Inf, 0.001, 0.01, 0.05, 0.1, Inf),
                      labels = c("***", "**", "*", ".", "")))
knitr::kable(pfiltered_WG2c)

#----Between Group comparison of First of P3-------
ioa3c <- emmeans(bestModel, pairwise ~ Phase * Group,
                 type = 'response',
                 CIs = TRUE,
                 plotit = FALSE,
                 adjust = "none",
                 at = list(
                   Bin_Centered = c(3)))
summary(ioa3c)


filtered_BG3c <- ioa3c$contrasts %>%
  as.data.frame() %>%
  filter(
    contrast == "(C-3 Group1) / (C-3 Group2)" |
      contrast == "(C-3 Group1) / (C-3 Group3)" |
      contrast == "(C-3 Group1) / (C-3 Group4)" |
      contrast == "(C-3 Group2) / (C-3 Group3)" |
      contrast == "(C-3 Group2) / (C-3 Group4)" |
      contrast == "(C-3 Group3) / (C-3 Group4)" 
  )
kable(filtered_BG3c)
pfiltered_BG3c <- filtered_BG3c %>%
  mutate(p.adj = p.adjust(p.value, method = "holm"), 
         signif = cut(p.adj,
                      breaks = c(-Inf, 0.001, 0.01, 0.05, 0.1, Inf),
                      labels = c("***", "**", "*", ".", "")))
knitr::kable(pfiltered_BG3c)

#Effect Sizes
d_pair <- function(g1, g2, phase, bin){
  raw_BG3c <- Data_Target %>%
    filter(Phase == phase, Bin == bin) 
  x <- raw_BG3c %>% filter(Group == g1) %>% pull(Rate)
  y <- raw_BG3c %>% filter(Group == g2) %>% pull(Rate)
  effsize::cohen.d(x, y, pooled = TRUE, hedges.correction = FALSE)
}


d_pair("1", "2", "C-3", 11)
d_pair("1", "3", "C-3", 11)
d_pair("1", "4", "C-3", 11)
d_pair("2", "3", "C-3", 11)
d_pair("2", "4", "C-3", 11)
d_pair("3", "4", "C-3", 11)


d_within_dz <- function(group, bin1, bin2, data = Data_Target) {
  
  temp <- data %>%
    filter(Group == group,
           Bin %in% c(bin1, bin2)) %>%
    select(ID, Bin, Rate) %>%
    tidyr::pivot_wider(
      names_from = Bin,
      values_from = Rate
    ) %>%
    na.omit()
  
  x <- temp[[as.character(bin1)]]
  y <- temp[[as.character(bin2)]]
  
  diff <- x - y
  
  effectsize::cohens_d(
    diff,
    mu = 0,
    ci = 0.95
  )
}

d_within_dz("1", 10, 11)
d_within_dz("2", 10, 11)
d_within_dz("3", 10, 11)
d_within_dz("4", 10, 11)

