rm(list = ls())

library(boot) #for bootstrapping
library(DHARMa) # Both have model diagnostic tools for LME
library(emmeans) # Helps interpreting LME models
library(ggplot2) # Charting
library(ggpubr) #for publication-ready plots
library(knitr) #for compiling the code into text or graphics
library(lmerTest) # Satterthwaite's approximation (p values for LME)
library(MuMIn) #for model inference (AIC and BIC)
library(nlme) #for non-linear MEM
library(tidyverse) # Data management
library(vcdExtra) #for visualizing categorical data (helpful for glmer)
library(aods3) #for analysis of overdispersion
library(stringr) #for manipulating characters
library(glmmTMB)
library("readxl")
library(writexl)
library(ggh4x)

#######
#Modify Working Directory
setwd("/Users/angelvillalobos/Desktop/LAB/Projects/Punishment/Alt Punish Magnitude/Submission/GitHub/")
All_Data <- read_xlsx("Data.xlsx")


resp_model <- "Target"

Data_Target <- All_Data %>%
  filter(RespType == resp_model, Phase %in% c("B-1", "A-2", "C-3"))
Data_Target$ID <- as.factor(Data_Target$ID)
Data_Target$Group <- as.factor(Data_Target$Group)
Data_Target$Phase <- as.factor(Data_Target$Phase)
Data_Target$Exp <- as.factor(Data_Target$Exp)
##Data Inspection
Data_Target %>% 
  ggplot(aes(x = Bin, 
             y = Rate,
             color = Group))+
  geom_line(aes(group = ID),
            linewidth   = 0.3)+
  geom_vline(xintercept = c(5.5, 10.5, 15.5))+
  theme_bw()

Data_Target %>%
  group_by(Group, Phase, Bin, Exp) %>%
  dplyr::summarise(rawMeans = mean(Rate),
                   se   = sd(Rate)/sqrt(n()), .groups = "drop") %>%
  ggplot(aes(x = Bin, y = rawMeans, color=Group)) +
  geom_line() +
  geom_errorbar(aes(ymin = rawMeans - se, ymax = rawMeans + se))+
  geom_vline(xintercept = c(5.5, 10.5, 15.5))+
  facet_wrap(~Exp)+
  theme_bw()

data_1 <- Data_Target %>% filter(Exp == 1)
data_2 <- Data_Target %>% filter(Exp == 2)

#Centering Bin
data_1$Bin_Centered <- data_1$Bin - mean(data_1$Bin, na.rm = TRUE)
data_2$Bin_Centered <- data_2$Bin - mean(data_2$Bin, na.rm = TRUE)
#Adding observational-level
data_1$obs <- 1:nrow(data_1) 
data_2$obs <- 1:nrow(data_2) 

model1 <- glmmTMB(Rate ~Bin_Centered*Phase + Bin_Centered*Group + Phase*Group + (1|ID),
                  ziformula = ~Phase + Bin_Centered,
                  family = nbinom2(),
                  data_1)
model2 <- glmmTMB(Rate ~Bin_Centered*Phase + Bin_Centered*Group + Phase*Group + (1|ID),
                  ziformula = ~Phase + Bin_Centered,
                  family = nbinom2(),
                  data_2)

#Post Hocs
#-Exp 1-------
emm_resp <- emmeans(model1, ~ Bin_Centered * Phase | Group,
                    at = list(
                      Bin_Centered = c(2, 3))) %>% regrid(transform = "response")
ioa2c <- pairs(
  emm_resp,
  reverse = TRUE,
  adjust = "none"
)

tabla_contrastes <- as.data.frame(
  summary(ioa2c, infer = c(TRUE, TRUE), adjust = "none")
)

filtered_WG2c <- tabla_contrastes %>%
  filter(
    contrast == "(Bin_Centered3 C-3) - (Bin_Centered2 A-2)",
    Group %in% 1:4
  )

pfiltered_WG2c <- filtered_WG2c %>%
  mutate(
    p.adj = p.adjust(p.value, method = "holm"),
    signif = cut(
      p.adj,
      breaks = c(-Inf, 0.001, 0.01, 0.05, 0.1, Inf),
      labels = c("***", "**", "*", ".", "")
    )
  )
knitr::kable(pfiltered_WG2c)

#--Exp 2-------
emm_resp_2 <- emmeans(model2, ~ Bin_Centered * Phase | Group,
                      #component = "response",
                      at = list(
                        Bin_Centered = c(2, 3))) %>% regrid(transform = "response")
ioa2c_2 <- pairs(
  emm_resp_2,
  reverse = TRUE,
  adjust = "none"
)

tabla_contrastes_2 <- as.data.frame(
  summary(ioa2c_2, infer = c(TRUE, TRUE), adjust = "none")
)

filtered_WG2c_2 <- tabla_contrastes_2 %>%
  filter(
    contrast == "(Bin_Centered3 C-3) - (Bin_Centered2 A-2)",
    Group %in% 1:4
  )

pfiltered_WG2c_2 <- filtered_WG2c_2 %>%
  mutate(
    p.adj = p.adjust(p.value, method = "holm"),
    signif = cut(
      p.adj,
      breaks = c(-Inf, 0.001, 0.01, 0.05, 0.1, Inf),
      labels = c("***", "**", "*", ".", "")
    )
  )
knitr::kable(pfiltered_WG2c_2)

#Additivity
# Experiment 1
filas_exp1 <- as.data.frame(ioa2c) %>%
  mutate(fila = row_number()) %>%
  filter(
    contrast == "(Bin_Centered3 C-3) - (Bin_Centered2 A-2)",
    Group %in% 1:4
  ) %>%
  arrange(Group)

# Experiment 2
filas_exp2 <- as.data.frame(ioa2c_2) %>%
  mutate(fila = row_number()) %>%
  filter(
    contrast == "(Bin_Centered3 C-3) - (Bin_Centered2 A-2)",
    Group %in% 1:4
  ) %>%
  arrange(Group)

dif_exp1 <- ioa2c[filas_exp1$fila, ]
dif_exp2 <- ioa2c_2[filas_exp2$fila, ]

#Efecto Y = Effect of RC in isolation
#Efecto X = Effect of Extinction in isolation
#Efecto XY = Effect of RC + Extinction

efecto_Y_exp1 <- dif_exp1[2:4, ]
efecto_X_exp2 <- dif_exp2[1:1, ]
efecto_XY_exp2 <- dif_exp2[2:4, ]

efecto_Y_exp2 <- contrast(
  dif_exp2,
  method = "trt.vs.ctrl",
  ref = 1,
  by = NULL,
  adjust = "none"
)

summary(efecto_Y_exp1, infer = c(TRUE, TRUE))
summary(efecto_X_exp2, infer = c(TRUE, TRUE))
summary(efecto_XY_exp2, infer = c(TRUE, TRUE))
summary(efecto_Y_exp2, infer = c(TRUE, TRUE))

res_exp1 <- as.data.frame(summary(efecto_Y_exp1))
res_exp2 <- as.data.frame(summary(efecto_X_exp2))
res_exp2_xy <- as.data.frame(summary(efecto_XY_exp2))
res_exp2_y <- as.data.frame(summary(efecto_Y_exp2, infer = c(TRUE, TRUE)))

tabla_aditividad <- data.frame(
  RC = c("-100", "-320", "-1000"),
  RC_Alone = res_exp1$estimate,
  Extinction_Alone = res_exp2$estimate,
  Extinction_RC = res_exp2_xy$estimate,
  Expected_Ext_RC = res_exp1$estimate + res_exp2$estimate,
  estimate = res_exp2_xy$estimate - (res_exp1$estimate + res_exp2$estimate),
  SE = sqrt(res_exp2_y$SE^2 + res_exp1$SE^2)
) 

tabla_aditividad <- tabla_aditividad %>%
  mutate(
    z.ratio = estimate / SE,
    p.value = 2 * pnorm(-abs(z.ratio)),
    lower.CL = estimate - qnorm(0.975) * SE,
    upper.CL = estimate + qnorm(0.975) * SE,
    p.adj = p.adjust(p.value, method = "holm")
  )

knitr::kable(tabla_aditividad, digits = 2)

